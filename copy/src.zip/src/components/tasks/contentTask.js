import React, { useState, useContext } from "react";

import taskData from "../../json/taskData";
import "./contentTask.css";
import { dateContext } from "../context/ContextDate";
import CssBaseline from "@material-ui/core/CssBaseline";
import { ThemeProvider } from "@material-ui/core/styles";
import normalFont from "../../Themes/normalFont";
import deleteIcon from "../../img/delete.svg";
import { from } from "stylis";
function ContentTask() {
  const { selectedDate } = useContext(dateContext);
  return (
    <ThemeProvider theme={normalFont}>
      <CssBaseline />
      {taskData[selectedDate].tasks.map((item, index) => (
        <div className="contentTask">
          <div className="first">
            <p>{item.title}</p>
            <p className="desTask">{item.description}</p>
          </div>
          <div className="second">
            <p>{item.time}</p>
          </div>

          <div className="third">
            <input type="checkbox" className="checkbox" />
            <img src={deleteIcon} className="deleteIcon"></img>
          </div>
        </div>
      ))}
    </ThemeProvider>
  );
}

export default ContentTask;
