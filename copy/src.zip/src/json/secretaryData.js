const secretaryData = [
  {
    id: 0,
    name: "علیرضا امید بخش",
    phoneNumber: "09124459863",
    programSecretary: true,
    meetingSecretary: false,
    contentSecretary: true,
    availability: ["منشی برنامه ها ، ", " منشی محتوا"],
  },
  {
    id: 1,
    name: "سارا رستگار ",
    phoneNumber: "09353659812",
    programSecretary: true,
    meetingSecretary: true,
    contentSecretary: true,
    availability: [" منشی جلسات ، ", "منشی برنامه ها ، ", "منشی محتوا"],
  },
  {
    id: 2,
    name: "محمد کریمی",
    phoneNumber: "09192359864",
    programSecretary: false,
    meetingSecretary: false,
    contentSecretary: true,
    availability: ["منشی محتوا"],
  },
];

export default secretaryData;
