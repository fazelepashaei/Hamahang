import DrawerPage from "./components/drawer";
import { CacheProvider } from "@emotion/react";
// import ShomareSerial from "./components/shomareSerial";
import createCache from "@emotion/cache";
import rtlPlugin from "stylis-plugin-rtl";
// import LocalStorage from "./components/localStorage";
// import ShomareTamas from "./components/shomareTamas";
// import CodeTaeid from "./components/codeTaeid";
// import TaeinRamz from "./components/taeinRamz";
import MenuFilter from "./components/menu";
import EndedMeeting from "./components/endedMeeting/endedMeeting";

import { Routes, Route, BrowserRouter } from "react-router-dom";
import "./App.css";
import Jalasat from "./components/jalasat";
import Tasks from "./components/tasks/tasks";
import Secretary from "./components/secretary/secretary";
import AppTestt from "./test";

const cacheRtl = createCache({
  key: "muirtl",
  stylisPlugins: [rtlPlugin],
});
function App() {
  return (
    <CacheProvider value={cacheRtl}>
      <div className="App">
        <BrowserRouter>
          <Routes>
            <Route path="/" element={<Jalasat />} />
            <Route path="EndedMeeting" element={<EndedMeeting />} />
            <Route path="Tasks" element={<Tasks />} />
            <Route path="Secretary" element={<Secretary />} />
          </Routes>
        </BrowserRouter>
        {/* <AppTestt /> */}
      </div>
      //{" "}
    </CacheProvider>
  );
}

export default App;
