const AttachData = [
  {
    id: 0,
    filename: "فایل عکس ها",
  },
  {
    id: 1,
    filename: "معاون",
  },
  {
    id: 2,
    filename: "فایل جلسات خصوصی",
  },
];
export default AttachData;
