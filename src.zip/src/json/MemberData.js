const MemberData = [
  {
    id: "۰",
    name: "علیرضا امید بخش",
    position: "مدیر",
    organization: "کنترل آب و هوا",
    information: "سخنرانی در جلسه ماهانه و بررسی آب و هوای فرودگاه مهرآباد",
  },
  {
    id: "۱",
    name: "سارا رستگار ",
    position: "معاون",
    organization: "فولاد مبارکه سپاهان",
    information: " کنترل ارز و بررسی بازار بورس",
  },
  {
    id: "۲",
    name: "محمد کریمی",
    position: "سهامدار",
    organization: "فولاد مبارک اصفهان",
    information: " انتساب اعضای اصلی ",
  },
];
export default MemberData;
