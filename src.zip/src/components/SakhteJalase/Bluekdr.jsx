function Bluekadr() {
  return (
    <div
      style={{
        width: "320px",
        height: "40px",
        backgroundColor: "#96C9F8",
        marginTop: "0%",
        marginBottom: "5%",
        // borderRadius: "25px",
        borderTopLeftRadius: "10px",
        borderTopRightRadius: "10px",
      }}
    >
      <h3
        style={{
          marginTop: "auto",
          marginBottom: "auto",
          color: "white",
          fontWeight: "bold",
        }}
      >
        ساخت جلسه
      </h3>
    </div>
  );
}

export default Bluekadr;
