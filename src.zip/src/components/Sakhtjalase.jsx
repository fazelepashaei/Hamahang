function SakhteJalase() {
  return (
    <div style={{ width: "20%", height: "10%", backgroundColor: "blue" }}></div>
  );
}

export default SakhteJalase;
