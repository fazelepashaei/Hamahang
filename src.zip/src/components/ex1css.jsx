.contentSecretary {
    display: flex;
    flex-direction: row;
    /* justify-content: space-around; */
    /* align-items: flex-end; */
    background-color: rgb(211, 5, 5);
    margin-top: 12px;
    margin-bottom: 12px;
    border-color: rgb(243, 241, 237);
  
    border-width: 2px;
    border-style: solid;
    border-radius: 7px;
    /* margin-left: 60px;
    margin-right: 85px; */
    width: 85%;
    height: 80px;
  }
  
  .firstSecretary {
    display: flex;
    flex-direction: column;
    /* justify-content: flex-start;
    align-items: flex-end; */
    width: 15%;
  }
  .secondSecretary {
    width: 15%;
  }
  