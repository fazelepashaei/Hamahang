import "./Josh1.css";
// import "../img/logo.png";
import companyLogo from "../img/logo.png";
import Buttons from "react-multi-date-picker/components/button";

function Josh1() {
  return (
    <div>
      <div className="contain1">
        {/* <header>
        <div className="max-width-wrapper">
          <div className="intro-chunk">
            <h1 className="title">Huckelbery</h1>
            <p>
              an avent grate agency foucused on connecting
              <strong> pathion</strong> with <strong>logestic</strong>
            </p>
            <p>a better way to solve the problem when problem is hard </p>
          </div>
        </div>
      </header>
      <main>
        <section className="max-width-wrapper">
          <div className="card">
            <h2 className="indented-heading">walts come an operation</h2>
            <p>
              no moderen busness can be no moderen busness can be no moderen
              busness can be no moderen busness can be no moderen busness can be
              no moderen busness can be no moderen busness can be no moderen
              busness can be no moderen busness can become mod
            </p>
          </div>
        </section>
      </main> */}
        <span className="smallonly">welcome</span>
      </div>
      <div className="two">
        <button>clickkk</button>
        <input placeholder="aaaa" type="text"></input>
        <label>ok</label>
        <p>helllow</p>
      </div>
    </div>
  );
}

export default Josh1;
