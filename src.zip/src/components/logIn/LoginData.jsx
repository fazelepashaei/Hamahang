const Data = [
  {
    id: "0",
    phone_number: "09121111",
    serial_number: "firstuser",
    verification_code: 1234,
    password: "first12",
  },
  {
    id: "1",
    phone_number: "09122222",
    serial_number: "seconduse",
    verification_code: 4567,
    password: "second34",
  },
  {
    id: "2",
    phone_number: "09129999",
    serial_number: "third user",
    verification_code: 8910,
    password: "third56",
  },
  {
    id: "3",
    phone_number: "09124444",
    serial_number: "fourth user",
    verification_code: 1112,
    password: "fourth78",
  },
  {
    id: "4",
    phone_number: "09125555",
    serial_number: "fifth user",
    verification_code: 1314,
    password: "fifth99",
  },
  {
    id: "5",
    phone_number: "09126666",
    serial_number: "sixth user",
    verification_code: 1516,
    password: "sixth66",
  },
  {
    id: "6",
    phone_number: "09127777",
    serial_number: "seventh user",
    verification_code: 1717,
    password: "sixth77",
  },
  {
    id: "7",
    phone_number: "09128888",
    serial_number: "eighth user",
    verification_code: 1718,
    password: "eighth88",
  },
];
export default Data;
